<?php

return [
    'by_pageview'  => 'Nga pageview',
    'by_sessions'  => 'Nga sesionet',
    'by_users'     => 'Nga përdoruesit',
    'no_client_id' => 'Për të parë analitikën që do t\'ju nevojitet për të marrë një ID '
    .'të klientit të analytics google dhe  shtoni në cilësimet tuaja për kodin '
    .'<code>google_analytics_client_id</code>. Merrni çelësin tuaj në tastierën zhvilluese të Google: ',
    'set_view'               => 'Zgjidh një pamje',
    'this_vs_last_week'      => 'Këtë javë ndaj javës së kaluar',
    'this_vs_last_year'      => 'Këtë vit kundër vitit të kaluar',
    'top_browsers'           => 'Shfletuesit kryesorë',
    'top_countries'          => 'Vendet më të mira',
    'various_visualizations' => 'Vizualizime të ndryshme',
];
