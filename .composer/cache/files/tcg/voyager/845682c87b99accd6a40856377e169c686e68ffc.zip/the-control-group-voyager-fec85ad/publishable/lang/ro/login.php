<?php

return [
    'loggingin'    => 'Logare în sistem',
    'signin_below' => 'Conectați-vă mai jos:',
    'welcome'      => 'Bine ați venit la Voyager. Panoul de control ce lipsește în Laravel',
];
