<?php

return [
    'invalid'           => 'هەڵە JSON',
    'invalid_message'   => 'وا دیارە کە JSON هەڵەت ناساندووە.',
    'valid'             => 'دروست JSON',
    'validation_errors' => 'ڕاستکردنەوە هەڵە بوو',
];
