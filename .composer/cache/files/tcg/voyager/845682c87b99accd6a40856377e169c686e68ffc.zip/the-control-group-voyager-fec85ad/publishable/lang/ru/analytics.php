<?php

return [
    'by_pageview'            => 'По страницам',
    'by_sessions'            => 'По сессиям',
    'by_users'               => 'По пользователям',
    'no_client_id'           => 'Для активации аналитики необходимо получить идентификатор клиента Google Analytics и добавить его в поле <code>google_analytics_client_id</code> меню настроек. Получить код Google Analytics: ',
    'set_view'               => 'Выберите вид',
    'this_vs_last_week'      => 'Текущая неделя в сравнении с прошлой.',
    'this_vs_last_year'      => 'Нынешний год в сравнении с прошлым',
    'top_browsers'           => 'Лучшие браузеры',
    'top_countries'          => 'Лучшие страны',
    'various_visualizations' => 'Различные визуализации',
];
