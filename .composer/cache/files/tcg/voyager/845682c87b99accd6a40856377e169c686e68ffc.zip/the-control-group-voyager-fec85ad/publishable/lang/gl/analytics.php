<?php

return [
    'by_pageview'            => 'Por páxina',
    'by_sessions'            => 'Por sesións',
    'by_users'               => 'Por usuarios',
    'no_client_id'           => 'Para ver os análisis, necesitará obter unha ID de cliente de Google Analytics e engadila á súa configuración para a clave <code>google_analytics_client_id</code>. Obteña a súa clave na consola de desarrolladores de Google: ',
    'set_view'               => 'Seleccionar unha vista',
    'this_vs_last_week'      => 'Esta semana vs a semana pasada',
    'this_vs_last_year'      => 'Este Ano vs o Ano pasado',
    'top_browsers'           => 'Principais Navegadores',
    'top_countries'          => 'Principais países',
    'various_visualizations' => 'Varias visualizacións',
];
