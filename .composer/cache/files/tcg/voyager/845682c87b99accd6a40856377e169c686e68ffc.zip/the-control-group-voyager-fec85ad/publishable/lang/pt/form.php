<?php

return [
    'field_password_keep'          => 'Deixar vazio para manter o atual',
    'field_select_dd_relationship' => 'Make sure to setup the appropriate relationship in the :method method of the :class class.',
    'type_checkbox'                => 'Check Box',
    'type_codeeditor'              => 'Editor de Código',
    'type_file'                    => 'Ficheiro',
    'type_image'                   => 'Imagem',
    'type_radiobutton'             => 'Radio Button',
    'type_richtextbox'             => 'Rich Textbox',
    'type_selectdropdown'          => 'Select Dropdown',
    'type_textarea'                => 'Text Area',
    'type_textbox'                 => 'Text Box',
];
