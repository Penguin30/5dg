<?php

return [
    'page'           => 'страница|страницы',
    'page_link_text' => 'Все страницы',
    'page_text'      => 'В базе данных :count :string',
    'post'           => 'запись|записи',
    'post_link_text' => 'Все записи',
    'post_text'      => 'В базе данных :count :string',
    'user'           => 'пользователь|пользователей',
    'user_link_text' => 'Все пользователи',
    'user_text'      => 'В базе данных :count :string',
];
