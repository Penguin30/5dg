<?php

return [
    'last_week' => 'Minggu Lalu',
    'last_year' => 'Tahun Lalu',
    'this_week' => 'Minggu Ini',
    'this_year' => 'Tahun Ini',
];
