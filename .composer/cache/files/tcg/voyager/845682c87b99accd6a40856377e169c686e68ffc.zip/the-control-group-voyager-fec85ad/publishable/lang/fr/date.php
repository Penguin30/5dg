<?php

return [
    'last_week' => 'La semaine dernière',
    'last_year' => 'L\'année dernière',
    'this_week' => 'Cette semaine',
    'this_year' => 'Cette année',
];
