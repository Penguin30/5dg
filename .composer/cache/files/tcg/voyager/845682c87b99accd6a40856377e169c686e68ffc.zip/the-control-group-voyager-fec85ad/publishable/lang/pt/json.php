<?php

return [
    'invalid'           => 'JSON Inválido',
    'invalid_message'   => 'Submeteu um JSON inválido.',
    'valid'             => 'JSON Válido',
    'validation_errors' => 'Erros de validação',
];
