<?php

return [
    'symlink_created_text'   => 'Noi tocmai am creat legătura simbolică(symlink) pentru dvs.',
    'symlink_created_title'  => 'Legătura simbolică a folderului storage ce lipsea, a fost creată.',
    'symlink_failed_text'    => 'Nu am putut genera link-ul simbolic ce lipsește pentru aplicația dvs. Se pare că hosting provider-ul dvs. nu suportă symlinks))).',
    'symlink_failed_title'   => 'Nu am putut crea link-ul simbolic pentru folderul storage.',
    'symlink_missing_button' => 'Corectați',
    'symlink_missing_text'   => 'Nu am putut găsi un link simbolic pentru folderul storage. Aceasta poate cauza probleme cu încărcarea fișierelor media de către browser.',
    'symlink_missing_title'  => 'Lipsește link-ul simbolic pentru folderul storage.',
];
