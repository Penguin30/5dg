<?php

return [
    'symlink_created_text'   => 'Acabamos de crear o enlace simbólico que faltaba para vostede.',
    'symlink_created_title'  => 'Enlace simbólico de almacenamento faltante creado',
    'symlink_failed_text'    => 'Non poidemos xerar o enlace simbólico perdido para a súa aplicación. Parece que o proveedor de aloxamento non o admite.',
    'symlink_failed_title'   => 'Non se poido crear un enlace simbólico de almacenamento faltante',
    'symlink_missing_button' => 'Arránxao',
    'symlink_missing_text'   => 'Non pudemos atopar un enlace simbólico de almacenamento. Isto podría causar problemas coa carga de arquivos multimedia dende o navegador.',
    'symlink_missing_title'  => 'Falta o enlace simbólico de almacenamento',
];
