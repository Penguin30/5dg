<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Upravit profil',
    'edit_user'     => 'Upravit uživatele',
    'password'      => 'Heslo',
    'password_hint' => 'Zanechte prázdné, pokud chcete uchovat stávající heslo',
    'role'          => 'Role',
    'user_role'     => 'Uživatelská role',
];
