<?php

return [
    'loggingin'    => 'دخول',
    'signin_below' => 'تسجيل الدخول :',
    'welcome'      => 'مرحبا بكم في Voyager. لوحة التحكم المكملة للارافيل',
];
