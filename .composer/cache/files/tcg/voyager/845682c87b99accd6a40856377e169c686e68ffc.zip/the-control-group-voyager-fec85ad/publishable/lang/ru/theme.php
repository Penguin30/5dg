<?php

return [
    'footer_copyright'  => 'Сделано с <i class="voyager-heart"></i> ',
    'footer_copyright2' => 'Сделано под ромом :) ',
];
