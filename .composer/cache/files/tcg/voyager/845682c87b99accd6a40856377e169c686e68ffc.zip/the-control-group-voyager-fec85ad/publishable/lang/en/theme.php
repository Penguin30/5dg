<?php

return [
    'footer_copyright'  => 'Made with <i class="voyager-heart"></i> by',
    'footer_copyright2' => 'Made with rum and even more rum',
];
