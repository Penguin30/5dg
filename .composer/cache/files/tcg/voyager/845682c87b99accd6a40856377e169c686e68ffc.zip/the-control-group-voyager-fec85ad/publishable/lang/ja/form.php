<?php

return [
    'field_password_keep'          => '空にすれば現状が維持されます',
    'field_select_dd_relationship' => ':classクラスの:methodメソッドで適切な関係を設定してください。',
    'type_checkbox'                => 'チェックボックス',
    'type_codeeditor'              => 'コードエディタ',
    'type_file'                    => 'ファイル',
    'type_image'                   => 'イメージ',
    'type_radiobutton'             => 'ラジオボタン',
    'type_richtextbox'             => 'リッチテキスト',
    'type_selectdropdown'          => 'ドロップダウンリスト',
    'type_textarea'                => 'テキストエリア',
    'type_textbox'                 => 'テキスト',
];
