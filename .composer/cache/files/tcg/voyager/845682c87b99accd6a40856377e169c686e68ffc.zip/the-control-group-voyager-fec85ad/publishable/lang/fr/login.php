<?php

return [
    'loggingin'    => 'Se connecter',
    'signin_below' => 'Connectez-vous ci-dessous :',
    'welcome'      => 'Bienvenue dans Voyager, l\'espace admin qui manquait à Laravel',
];
