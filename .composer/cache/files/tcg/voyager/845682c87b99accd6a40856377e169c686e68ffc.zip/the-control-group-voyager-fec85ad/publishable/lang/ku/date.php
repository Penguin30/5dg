<?php

return [
    'last_week' => 'هەفتەی ڕابردوو',
    'last_year' => 'ساڵی ڕابردوو',
    'this_week' => 'ئەم هەفتەیە',
    'this_year' => 'ئەمساڵ',
];
