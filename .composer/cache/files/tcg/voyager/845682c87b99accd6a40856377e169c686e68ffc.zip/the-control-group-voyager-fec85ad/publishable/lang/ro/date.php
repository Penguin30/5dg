<?php

return [
    'last_week' => 'Săptămâna trecută',
    'last_year' => 'Anul trecut',
    'this_week' => 'Săptămâna asta',
    'this_year' => 'În acest an',
];
