<?php

return [
    'last_week' => 'Last Week',
    'last_year' => 'Last Year',
    'this_week' => 'This Week',
    'this_year' => 'This Year',
];
