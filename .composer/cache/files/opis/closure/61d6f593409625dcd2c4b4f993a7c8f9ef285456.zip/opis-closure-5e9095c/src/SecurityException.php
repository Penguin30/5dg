<?php
/* ===========================================================================
 * Copyright (c) 2018 Zindex Software
 *
 * Licensed under the MIT License
 * =========================================================================== */

namespace Opis\Closure;

use Exception;

/**
 * Security exception class
 */
class SecurityException extends Exception
{

}